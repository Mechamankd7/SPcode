from telnetlib import STATUS
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseNotFound
import sendgrid
import os
from sendgrid.helpers.mail import Mail, Email, To, Content
from django.views.decorators.csrf import csrf_exempt
import json
from . import db



x = 'x' 
y = 'y'
z = 'z'
sg = sendgrid.SendGridAPIClient(api_key='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')
# Create your views here.

def index(request):
    return HttpResponse('Set Up, Name - Threshold - Actual')
@csrf_exempt
def hello(request, x, y, z ):
    if y > z:
        emailNotification('ashkumar0726@gmail.com', x, y, z)
    return HttpResponse('App: ' + x + ' - ' + str(y) + ' - ' + str(z))
    

def emailNotification(email, username, x, prinln1, println2):
    print("ALERT " + x + " is running low!")
    print("Threshold-" + str(prinln1))
    print("Current"+ str(println2))

    from_email = Email("ashkumar0726@gmail.com")
    to_email = To(email)
    subject = "!WARNING! Pantry suplly running out!" 
    content = Content("text/plain", username + ", Your " + x + " is running out!")
    mail = Mail(from_email, to_email, subject, content)
    mail_json = mail.get()
    response = sg.client.mail.send.post(request_body=mail_json)
    print("Running low, Email sent!")

@csrf_exempt
def login(request):
    data = json.loads(request.body.decode("utf-8"))
    username = data["username"]
    password = data["password"]
    user = db.login(username, password)
    if user:
        return HttpResponse("User with id: " + str(user["id"]))
    else:
        return HttpResponseNotFound("Username or Password Invalid")

@csrf_exempt
def signup(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
        username = data["username"]
        password = data["password"]
        email = data["email"]
        user = db.createUser(username, password, email)
        return HttpResponse("User with Username: " + username + " created successfully with id: " + str(user["id"]))
    except Exception as e:
        return HttpResponseBadRequest(str(e)) 

@csrf_exempt
def getPantry(request, userId):
    pantryItems = db.getPantryItems(userId)
    return HttpResponse(str(pantryItems))

@csrf_exempt
def addPantryItem(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
        userId = data["userId"]
        item = data["item"]
        threshold = data["threshold"]
        pantryItem = db.addPantryItem(userId, item, threshold)
        return HttpResponse("Pantry item created successfully: " + str(pantryItem))
    except Exception as e:
        return HttpResponseBadRequest(str(e))

@csrf_exempt
def updatePantryItem(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
        userId = data["userId"]
        item = data["item"]
        threshold = data["threshold"]
        pantryItem = db.updatePantryItem(userId, item, threshold)
        return HttpResponse("Pantry item updated successfully: " + str(pantryItem))   
    except Exception as e:
        return HttpResponseBadRequest(str(e))

@csrf_exempt
def sensorAlert(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
        userId = data["userId"]
        item = data["item"]
        quantity = data["quantity"]
        pantryItem = db.getPantryItem(userId, item)
        t = pantryItem["threshold"]
        if t > quantity:
            user = db.getUser(userId)
            username = user['username']
            email = user['email']
            emailNotification(email, username, item, t, quantity)
            return HttpResponse("Alert has been sent successfully")
        return HttpResponse("Item still above threshold")
    except Exception as e:
        return HttpResponseBadRequest(str(e))