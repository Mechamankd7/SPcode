import sqlite3

def validateUsername(username):
        lenUsername = len(username)
        if lenUsername > 32:
            return False
        else:
            return True

def createDatabaseConnection():
    conn = sqlite3.connect("App.db")                        
    return conn

def endDatabaseConnection():
    conn = createDatabaseConnection
    conn.commit()
    conn.close()



def createDatabase():
    conn = createDatabaseConnection()
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS USERS (id integer primary key autoincrement , username text unique, password text, email text)")
    c.execute("CREATE TABLE IF NOT EXISTS pantry (user_id integer references users(id), item text, threshold integer, primary key (user_id, item))")
    c.execute("UPDATE SQLITE_SEQUENCE SET seq = 1000 WHERE name = 'users'")

def convertToUser(data):
    if data:
        user = {    
            "id": data[0],
            "username": data[1],
            "password":data[2],
            "email":data[3]
        }
        return user
    return
    
def convertToPantryItem(data):
    if data:
        item = {    
            "userId": data[0],
            "item": data[1],
            "threshold":data[2],
        }
        return item
    return

def getPantryItems(userId):
    conn = createDatabaseConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM pantry where user_id = ?", [userId])
    pantryItems = c.fetchall()
    pantryItems = list(map(convertToPantryItem, pantryItems))
    return pantryItems

def getPantryItem(userId, item):
    conn = createDatabaseConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM pantry where user_id = ? and item = ?", [userId, item])
    pantryItem = c.fetchone()
    pantryItem = convertToPantryItem(pantryItem)
    return pantryItem

def addPantryItem (userId, item, threshold):
    conn = createDatabaseConnection()
    c = conn.cursor()
    pantryItem = [(userId, item, threshold)]                  
    c.executemany("INSERT INTO pantry (user_id, item, threshold) VALUES (?,?,?)", pantryItem)
    conn.commit()
    c.execute("SELECT * FROM pantry where user_id = ? and item = ?", [userId, item])
    pantryItem = c.fetchone()
    pantryItem = convertToPantryItem(pantryItem)
    return pantryItem

def updatePantryItem (userId, item, threshold):
    conn = createDatabaseConnection()
    c = conn.cursor()
    pantryItem = [(threshold, userId, item)]                  
    c.executemany("UPDATE pantry set threshold = ? where user_id = ? and item = ?", pantryItem)
    conn.commit()
    c.execute("SELECT * FROM pantry where user_id = ? and item = ?", [userId, item])
    pantryItem = c.fetchone()
    pantryItem = convertToPantryItem(pantryItem)
    return pantryItem

def getUser(userId):
    conn = createDatabaseConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM users where id = ?", [userId])
    user = c.fetchone()
    user = convertToUser(user)
    return user

def createUser(username, password, email):
    conn = createDatabaseConnection()
    c = conn.cursor()
    user = [(username, password, email)]                  
    c.executemany("INSERT INTO users (username, password, email) VALUES (?,?,?)", user)
    conn.commit()
    c.execute("SELECT * FROM users where username = ?", [username])
    user = c.fetchone()
    user = convertToUser(user)
    return user



def login(username, password):
    conn = createDatabaseConnection()
    c = conn.cursor()
    c.execute("SELECT * FROM users where username = ? and password = ?",( username, password))
    user = c.fetchone()
    user = convertToUser(user)
    return user


createDatabase()
