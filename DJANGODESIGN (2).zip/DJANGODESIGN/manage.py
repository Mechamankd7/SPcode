#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'djangoTest.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()

#python manage.py runserver
#http://127.0.0.1:8000/App/signup           CREATES USER
#http://127.0.0.1:8000/App/login            VALIDATES USER,                                                                                (still need many options for validates)
#http://127.0.0.1:8000/App/pantry/9 (userID)GETS THE OUTPUTS         
#http://127.0.0.1:8000/App/pantry/add       ADDS AN OPTION
#http://127.0.0.1:8000/App/sensor           SENSES COMPARES
#http://127.0.0.1:8000/App/pantry/update    THRESHOLD UPDATE