from django.urls import path
from . import views

urlpatterns = [
    path('App', views.index ),
    path('App/login', views.login),
    path('App/signup', views.signup),
    path('App/pantry/<int:userId>', views.getPantry),
    path('App/pantry/add', views.addPantryItem),
    path('App/pantry/update', views.updatePantryItem),
    path('App/sensor', views.sensorAlert),
]